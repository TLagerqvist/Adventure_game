import time
import random


def print_pause(prompt, speed=1):
    print(prompt)
    time.sleep(speed)


def user_input(prompt, options, insult):
    while True:
        option = input(prompt).lower()
        if option in options:
            return option
        print_pause(insult, 1)


def title(items, boss, insult, power, speed, health, health_two):
    print_pause("THE SWORD OF MEDIOCRA", 3)


def intro(items, boss, insult, power, speed, health, health_two):
    print_pause("Somwhere in the world of Nothlonago...", 2)
    print_pause("You find yourself standing in an open field, "
                "filled with cans\n" "and old burger wrappers.", 3)
    print_pause("Rumor has it that the mighty " + boss +
                " is somewhere around here, \n" "and has been terrorizing "
                "the nearby town.", 3)
    print_pause("In your arsenal is an old pocket knife, "
                "blade about the size of a tooth pick", 2)
    print_pause("You approach an old house and a dark cave", 2)
    print_pause(" \n", 1)


def change_weapon(
                  items, boss, insult, power,
                  speed, health, health_two, wp, item, vl
                  ):
    power.clear()
    power.append(wp)
    items.clear()
    items.append(item)
    items.append(speed)
    speed.clear()
    speed.append(vl)


def weapon_power(items, boss, insult, power, speed, health, health_two):
    print_pause("Weapon power" + "[" + power[0] + "]"
                "\nSpeed" + "[" + speed[0] + "]"
                "\nWeapon" + "[" + items[0] + "]"
                "\nHealth bar" + "[" + health[0] + "]\n")


def band_aid(items, boss, insult, power, speed, health, health_two, hp):
    bandaid = int(health[0]) + hp
    health.clear()
    health.append(str(bandaid))


def field(items, boss, insult, power, speed, health, health_two):
    weapon_power(items, boss, insult, power, speed, health, health_two)

    choice = user_input("Enter 1 to knock the door of the house \n"
                        "Enter 2 to peer into the cave \n", ["1", "2"], insult)
    if choice == "1":
        house(items, boss, insult, power, speed, health, health_two)
    elif choice == "2":
        cave(items, boss, insult, power, speed, health, health_two)


def room_one(items, boss, insult, power, speed, health, health_two):
    if int(health[0]) < 21:
        band_aid(items, boss, insult, power, speed, health, health_two, 10)
        print_pause("You found a bandaid! [+10] health")
        print_pause("Let's head back to the hall")

    else:
        print_pause("You look around but don't find anything but an old \n"
                    "first aid kit," " let's head back")

    cave(items, boss, insult, power, speed, health, health_two)


def room_two(items, boss, insult, power, speed, health, health_two):
    print_pause("You slowly crawl through the tight space")
    print_pause("You are super nervous \n"
                "because this feels like a road to certain death...", 2)
    print_pause("You move a crate of old dynamite away \n"
                "and stumble over a weaponary!")
    print_pause("You forgot both leg day and arm day at the gym,\n"
                "so you can barely carry one of these", 3)

    choice = user_input("Do you take the sword or an axe? \n"
                        "[enter 1 or 2 ]\n", ["1", "2"], insult)

    if choice == "1":
        change_weapon(
                      items, boss, insult, power,
                      speed, health, health_two,
                      "6", "sword", "8"
                      )

    elif choice == "2":
        change_weapon(
                      items, boss, insult, power,
                      speed, health, health_two,
                      "9", "axe", "3"
                      )

    cave(items, boss, insult, power, speed, health, health_two)


def cave(items, boss, insult, power, speed, health, health_two):
    if "knife" not in items and int(health[0]) > 20:
        print_pause("You have chosen a weapon, time to get to business", 2)
        field(items, boss, insult, power, speed, health, health_two)

    else:
        print_pause("You are in the main hall of the cave")
        choice = user_input("There are two paths, left or right? \n"
                            "[enter 1 or 2 ]\n", ["1", "2"], insult)

        if choice == "1":
            room_one(items, boss, insult, power, speed, health, health_two)

        elif choice == "2":
            room_two(items, boss, insult, power, speed, health, health_two)


def house(items, boss, insult, power, speed, health, health_two):
    print_pause("You enter the old house...", 2)
    print_pause("Oh crap here we go!", 1)
    print_pause("it's the " + boss + "!", 2)
    if "knife" in items:
        print_pause("Your hands are trembling "
                    "as you reach for your pocket knife...", 2)

    else:
        print_pause("You have your " + str(items[0]) + " ready", 2)

    fight_or_flight(items, boss, insult, power, speed, health, health_two)


def fight_or_flight(items, boss, insult, power, speed, health, health_two):
    choice = user_input("Enter 1 to fight, or 2 to run away\n",
                        ["1", "2"], insult)
    if choice == "1":
        fight(items, boss, insult, power, speed, health, health_two)
    elif choice == "2":
        print_pause("You decide to scram", 2)
        print_pause("Seems the " + boss + " didn't follow you...", 2)
        print_pause("You are once again back on the field.", 2)
        field(items, boss, insult, power, speed, health, health_two)


def charge(items, boss, insult, power, speed, health, health_two):
    charge = (int(power[0])
              * random.randint(3, 5)
              + (int(speed[0])
              * random.randint(1, 2))
              - int(speed[0]))
    damage = int(health_two[0]) - charge

    health_two.clear()
    health_two.append(damage)

    print("You strike, he looses -" + str(charge) + "hp")


def attack(items, boss, insult, power, speed, health, health_two):
    attack = random.randint(15, 39) - int(power[0])
    damage = int(health[0]) - attack

    health.clear()
    health.append(str(damage))

    print("He strikes, you loose -" + str(attack) + "hp")


def fight(items, boss, insult, power, speed, health, health_two):
    attack(items, boss, insult, power, speed, health, health_two)

    if int(health[0]) < 1:
        print_pause("This was a terrible idea, "
                    "what were you going to use on that thing? \n", 1)
        print_pause("Bad language?", 2)
        print_pause("You have been defeated...", 2)
        print_pause("GAME OVER", 2)

    else:
        charge(items, boss, insult, power, speed, health, health_two)

        if int(health_two[0]) < 1:
            print_pause("You pull out your shiny new toy...", 2)
            print_pause("It's an epic battle between good and evil.\n"
                        "Since you had no sword fighting skills \n"
                        "you had to resor to diplomacy,\n"
                        "and the antagonist agreed to leave.\n", 3)
            print_pause("VICTORY!", 2)
            print_pause("A party was held in your honor, "
                        "autograph signing, etc.", 3)
            print_pause("End of game", 3)

        else:
            print_pause("Bad hit! Retreat!")
            print_pause("You run out of the door and back out on the field.")
            field(items, boss, insult, power, speed, health, health_two)


def replay():
    return user_input("Would you like to play again? (Y/N)\n",
                      ["y", "n"], "Please choose")


def exit_game():
    print_pause("END CREDITS\n" "\n ", 2)
    print_pause("This game was developed as a UDACITY project \n"
                "by Tobey.\n", 2)
    print_pause("\nThank's for playing!", 1)


def play_game():
    antagonist = ["Angry Duck", "Evil Santa",
                  "Blob", "Scoobydoo", "Steven"]
    boss = random.choice(antagonist)
    insults = ["Don't be a chicken",
               "A Toaster was officially braver than you now",
               "You can do better than that", "A shrimp has more spine"]
    insult = random.choice(insults)
    items = ["knife"]
    power = ["2"]
    speed = ["10"]
    health = ["30"]
    health_two = ["30"]
    title(items, boss, insult, power, speed, health, health_two)
    intro(items, boss, insult, power, speed, health, health_two)
    field(items, boss, insult, power, speed, health, health_two)


def game():
    while True:
        play_game()

        if replay() == "n":
            break
    exit_game()


if __name__ == '__main__':
    game()
